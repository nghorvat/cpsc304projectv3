
public class Zookeeper {
	
	private int zkId;
	private String fName;
	private String lName;
	
	public Zookeeper(int id) {
		this.zkId = id;
	}
	
	public void setZkId(int id) {
		this.zkId = id;
	}
	
	public void setFName(String fname) {
		this.fName = fname;
	}
	
	public void setLName(String lname) {
		this.lName = lname;
	}
	
	public int getZkId() {
		return this.zkId;
	}
	
	public String getFName() {
		return this.fName;
	}
	public String getLname() {
		return this.lName;
	}
}
