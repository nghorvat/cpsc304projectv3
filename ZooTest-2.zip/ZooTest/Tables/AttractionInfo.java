package tables;

public class AttractionInfo {
	private int attractionId;
	private String attractionName;
	private int minPoints;
	private String sectionName;
	
	// Constructor that builds based on the primary key
	public AttractionInfo(int attId) {
		this.attractionId = attId;
	}
	
	// "Setters"
	
	// Updates the attraction ID number
	public void setAttId(int attId) {
		this.attractionId = attId;
	}
	
	// Updates the name of the attraction
	public void setAttName(String aName) {
		this.attractionName = aName;
	}
		
	// Updates the minimum number of points to view the attraction
	public void setMinPoints(int points) {
		this.minPoints = points;
	}
	
	// Updates the attraction's section name
	public void setSectionName(String secName) {
		this.sectionName = secName;
	}
	
	// "Getters"
	
	// Return the attraction ID
	public int getAttId() {
		return this.attractionId;
	}
	
	// Return the attraction name
	public String getAttName() {
		return this.attractionName;
	}
	
	// Return the minimum number of points
	public int getMinPoints() {
		return this.minPoints;
	}
	
	// Return the section name
	public String getSectionName() {
		return this.sectionName;
	}
	
	
}
