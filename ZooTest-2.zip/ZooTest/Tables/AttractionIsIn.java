package tables;

import java.util.Date;

public class AttractionIsIn {
	private int attractionId;
	private Date showDate;
	private Date showTime;
	
	// Constructor that builds based on the primary key
	public AttractionIsIn(int attId, Date sDate, Date sTime) {
		this.attractionId = attId;
		this.showDate = sDate;
		this.showTime = sTime;
	}
	
	// "Setters"
	
	// Updates the attraction ID number
	public void setAttId(int attId) {
		this.attractionId = attId;
	}
	
	// Updates the show date of the attraction
	public void setShowDate(Date sDate) {
		this.showDate = sDate;
	}
	
	// Updates the show time of the attraction
	public void setShowTime(Date sTime) {
		this.showTime = sTime;
	}
		
	// "Getters"

	// Return the attraction ID
	public int getAttId() {
		return this.attractionId;
	}
	
	// Return the show date of the attraction
	public Date getShowDate(Date sDate) {
		return this.showDate;
	}
	
	// Return the show time of the attraction
	public Date getShowTime(Date sTime) {
		return this.showTime;
	}
}
