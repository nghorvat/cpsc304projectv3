package tables;

import java.util.Date;

public class PerformsIn {
	private String animalId; // animal id is a string
	private int attractionId;
	private Date showTime;
	private Date showDate;
	
	// Constructor that builds based on the primary key
	public PerformsIn(String aniId, int attId, Date sTime, Date sDate) {
		this.animalId = aniId;
		this.showTime = sTime;
		this.showDate = sDate;
		this.attractionId = attId;
	}
	
	// "Setters"
	
	// Updates the show time for show being performed
	public void setShowTime(Date sTime) {
		this.showTime = sTime;
	}
	
	// Updates the show date for show being performed
	public void setShowDate(Date sDate) {
		this.showDate = sDate;
	}
	
	// Updates the attraction for show being performed
	public void setAttractionID(int id) {
		this.attractionId = id;
	}
	
	// Updates the performing animals ID
	public void setAnimalId(String aniId) {
		this.animalId = aniId;
	}
	
	// "Getters"
	
	// Return the animal ID
	public String getAnimalId() {
		return this.animalId;
	}
	
	// Return the show start time
	public Date getShowTime() {
		return this.showTime;
	}
	
	// Return the show date
	public Date getShowDate() {
		return this.showDate;
	}
	
	// Return the attraction id
	public int getAttractionId() {
		return this.attractionId;
	}

}
