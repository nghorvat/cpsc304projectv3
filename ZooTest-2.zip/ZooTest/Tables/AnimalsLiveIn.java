import java.util.Date;

public class AnimalsLiveIn {
	private String aId;
	private String aGender;
	private String aType;
	private String aName;
	private String reasonAdded;
	private Date dateAdded;
	
	public AnimalsLiveIn(String aid) {
		this.aId = aid;
	}
	
	public void setAId(String aid) {
		this.aId = aid;
	}
	
	public void setAGender(String gender) {
		this.aGender = gender;
	}
	
	public void setAType(String type) {
		this.aType = type;
	}
	
	public void setAName(String name) {
		this.aName = name;
	}
	
	public void setReasonAdded(String reason) {
		this.reasonAdded = reason;
	}
	
	public void setDateAdded(Date date) {
		this.dateAdded = date;
	}
	
	public String setAId() {
		return this.aId;
	}
	
	public String setAGender() {
		return this.aGender;
	}
	
	public String setAType() {
		return this.aType;
	}
	
	public String setAName() {
		return this.aName;
	}
	
	public String setReasonAdded() {
		return this.reasonAdded;
	}
	
	public Date setDateAdded() {
		return this.dateAdded;
	}
}
