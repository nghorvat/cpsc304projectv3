package tables;

import java.util.Date;

public class Sees {
	private String emailAddress;
	private int attractionId;
	private Date showTime;
	private Date showDate;
	
	// Constructor that builds based on the primary key
	public Sees(String email, int attId, Date sTime, Date sDate) {
		this.emailAddress = email;
		this.showTime = sTime;
		this.showDate = sDate;
		this.attractionId = attId;
	}
	
	// "Setters"
	
	// Updates the show time for show being seen
	public void setShowTime(Date sTime) {
		this.showTime = sTime;
	}
	
	// Updates the show date for show being seen
	public void setShowDate(Date sDate) {
		this.showDate = sDate;
	}
		
	// Updates the attraction for show being seen
	public void setAttractionID(int id) {
		this.attractionId = id;
	}
	
	// Updates the attraction for show being seen
	public void setEmail(String email) {
		this.emailAddress = email;
	}
	
	// "Getters"
	
	// Return the email address
	public String getEmail() {
		return this.emailAddress;
	}
	
	// Return the show start time
	public Date getShowTime() {
		return this.showTime;
	}
	
	// Return the show date
	public Date getShowDate() {
		return this.showDate;
	}
	
	// Return the attraction id
	public int getAttractionId() {
		return this.attractionId;
	}
}
