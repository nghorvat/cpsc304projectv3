
public class EnclosureIsIn {
	
	private int eid;
	private String sectionName;
	private int capacity;
	private int eSize;

	public EnclosureIsIn(int eid) {
		this.eid = eid;
	}
	
	public void setEid(int id) {
		this.eid = id;
	}
	
	public void setSectionName(String name) {
		this.sectionName = name;
	}
	
	public void setCapacity(int cap) {
		this.capacity = cap;
	}
	
	public void setESize(int size) {
		this.eSize = size;
	}
	
	public int getEid() {
		return this.eid;
	}
	
	public String getSectionName() {
		return this.sectionName;
	}
	
	public int getCapacity() {
		return this.capacity;
	}
	
	public int getESize() {
		return this.eSize;
	}
	

}
