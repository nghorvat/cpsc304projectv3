
public class Task {
	
	private int tId;
	private String description;
	
	public Task(int id) {
		this.tId = id;
	}
	
	public void setTId(int id) {
		this.tId = id;
	}
	
	public void setdescription(String description) {
		this.description = description;
	}
	
	public int getTId() {
		return this.tId;
	}
	
	public String getDescription() {
		return this.description;
	}

}
