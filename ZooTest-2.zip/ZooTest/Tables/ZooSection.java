
public class ZooSection {
	private String sectionName;
	private String sectionTheme;
	
	public ZooSection(String name) {
		this.sectionName = name;
	}
	
	public void setSectionName(String name) {
		this.sectionName = name;
	}
	
	public void setSectionTheme(String theme) {
		this.sectionTheme = theme;
	}
	
	public String getSectionName() {
		return this.sectionName;
	}
	
	public String getSectionTheme() {
		return this.sectionTheme;
	}

}
