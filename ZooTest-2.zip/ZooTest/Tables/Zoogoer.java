
public class Zoogoer {
	private String email;
	private String fname;
	private String lname;
	
	public Zoogoer(String email) {
		this.email = email;
	}
	
	public void set(String fname, String lname) {
		this.fname = fname;
		this.lname = lname;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public String getFname() {
		return this.fname;
	}
	
	public String getLname(){
		return this.lname;
	}
}
