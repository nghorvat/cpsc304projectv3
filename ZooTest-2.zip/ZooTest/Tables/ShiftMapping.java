import java.util.Date;

public class ShiftMapping {
	
	private Date shiftStart;
	private Date day;
	
	public ShiftMapping(Date start) {
		this.shiftStart = start;
	}
	
	public void setShiftStart(Date start) {
		this.shiftStart = start;
	}
	
	public void setDay(Date day) {
		this.day = day;
	}
	
	public Date getShiftStart() {
		return this.shiftStart;
	}
	
	public Date getDay() {
		return this.day;
	}
}
