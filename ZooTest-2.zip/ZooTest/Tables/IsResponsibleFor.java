import java.util.Date;

public class IsResponsibleFor {
	
	private int zkId;
	private int tId;
	private String aId;
	private Date dueDate;
	private String isDone;
	
	public IsResponsibleFor(int zkid, int tid, int aid) {
		this.zkId = zkid;
		this.tId = tid;
		this.aId = aid;
	}
	
	public void setZkId(int id){
		this.zkId = id;
	}
	
	public void setTId(int id) {
		this.tId = id;
	}
	
	public void setAId(String id){
		this.aId = id;
	}
	
	public void setDueDate(Date date) {
		this.dueDate = date;
	}
	
	public void setIsDone(String done) {
		this.isDone = done;
	}
	public int getZkId(){
		return this.zkId;
	}
	
	public int getTId() {
		return this.tId;
	}
	
	public String setAId(){
		return this.aId;
	}
	
	public Date setDueDate() {
		return this.dueDate;
	}
	
	public String setIsDone() {
		return this.isDone;
	}

}
