
public class Member {
	private String email;
	private int mid;
	private int mpoints;
	private int visits;
	
	public Member(String email) {
		this.email = email;
		this.mid = 0;
		this.mpoints = 0;
		this.visits = 0;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public void setMpoints(int points) {
		this.mpoints = points;
	}
	public void setVisits(int visits) {
		this.visits = visits;
	}
	public String getEmail() {
		return this.email;
	}
	public int getMid() {
		return this.mid;
	}
	public int getMpoints() {
		return this.mpoints;
	}
	public int getVisits() {
		return this.visits;
	}
}
