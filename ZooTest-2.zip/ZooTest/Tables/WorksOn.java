
public class WorksOn {
	private int zkId;
	private int shiftId;
	
	public WorksOn(int zk, int shift) {
		this.zkId = zk;
		this.shiftId = shift;
	}
	
	public void setZkId(int id) {
		this.zkId = id;
	}
	
	public void setShiftId(int id) {
		this.shiftId = id;
	}
	
	public int getZkId() {
		return this.zkId;
	}
	
	public int getShiftId() {
		return this.shiftId;
	}
}
