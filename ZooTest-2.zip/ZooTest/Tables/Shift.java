import java.util.Date;

public class Shift {
	
	private int shiftId;
	private Date shiftStart;
	private Date shiftEnd;
	
	public Shift(int id) {
		this.shiftId = id;
	}
	
	public void setShiftId(int id) {
		this.shiftId = id;
	}
	
	public void setShiftStart(Date start) {
		this.shiftStart = start;
	}
	
	public void setShiftEnd(Date end) {
		this.shiftEnd = end;
	}
	
	public int getShiftId() {
		return this.shiftId;
	}
	
	public Date getShiftStart() {
		return this.shiftStart;
	}
	
	public Date getShiftEnd() {
		return this.shiftEnd;
	}
}
