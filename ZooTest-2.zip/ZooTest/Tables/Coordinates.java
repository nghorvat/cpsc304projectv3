package tables;

import java.util.Date;

public class Coordinates {
	private int zkId;
	private Date showTime;
	private Date showDate;
	private int attractionId;
	
	// Constructor that builds based on the primary key
	public Coordinates(int zId, Date sTime, Date sDate, int aId) {
		this.zkId = zId;
		this.showTime = sTime;
		this.showDate = sDate;
		this.attractionId = aId;
	}
	
	// "Setters"
	
	// Updates the zoo-keeper id for show being coordinated
	public void setZkid(int zId) {
		this.zkId = zId;
	}
	
	// Updates the show time for show being coordinated
	public void setShowTime(Date sTime) {
		this.showTime = sTime;
	}
	
	// Updates the show date for show being coordinated
	public void setShowDate(Date sDate) {
		this.showDate = sDate;
	}
	
	// Updates the attraction for show being coordinated
	public void setAttractionID(int id) {
		this.attractionId = id;
	}
	
	// "Getters"
	
	// Return the zoo-keeper id
	public int getZkId() {
		return this.zkId;
	}
	
	// Return the show start time
	public Date getShowTime() {
		return this.showTime;
	}
	
	// Return the show date
	public Date getShowDate() {
		return this.showDate;
	}
	
	// Return the attraction id
	public int getAttractionId() {
		return this.attractionId;
	}
	
}
