
public class ZooBean {
	

}
