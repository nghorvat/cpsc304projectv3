
drop table sees;
drop table performsin;
drop table coordinates;
drop table attractionisin;
drop table attractioninfo;

drop table isresponsiblefor;
drop table animalslivein;
drop table enclosureisin;
drop table zoosection;
drop table task;
drop table workson;
drop table zookeeper;
drop table shift;
drop table shiftmapping;
drop table member;
drop table zoogoers;



create table zoogoers
	(email char(50) not null,
	 fname char(30) null,
	 lname char(30) null,
	 primary key (email));

create table member
	(email char(50) not null,
	 mid integer not null,
	 mpoints integer null, 
	 visits integer null,
	 primary key (email, mid),
	 foreign key (email) references zoogoers);

create table zoosection
	(sectionname char(50) not null, 
	 sectiontheme varchar(200) null,
	 primary key (sectionname));

create table enclosureisin
	(eid integer not null,
	 sectionname char(50) not null,
	 capacity integer null, 
	 esize integer null, 
	 primary key (eid),
	 foreign key (sectionname) references zoosection ON DELETE CASCADE);

create table animalslivein
  (aid char(15) not null,
	 agender char(8) null, 
	 atype char(15) null, 
	 aname char(20) null, 
	 reasonadded varchar(200) null, 
	 dateadded date null,
	 eid integer not null,
	 primary key (aid),
	 foreign key (eid) references enclosureisin ON DELETE CASCADE);


create table shiftmapping
  (shiftstart timestamp,
   day date null,
   primary key (shiftstart));
	 
create table shift
	(shiftid integer not null,
	 shiftstart timestamp null, 
	 shiftend timestamp null,
	 primary key (shiftid),
	 foreign key (shiftstart) references shiftmapping ON DELETE CASCADE);

create table task
	(tid integer not null, 
	 description varchar(200) null,
	 primary key (tid));

create table zookeeper
	(zkid integer not null, 
	 fname char(30) null, 
	 lname char(30) null,
	 primary key (zkid));

create table workson
	(zkid integer not null, 
	 shiftid integer not null,
	 primary key (zkid, shiftid),
	 foreign key (zkid) references zookeeper ON DELETE CASCADE,
	 foreign key (shiftid) references shift ON DELETE CASCADE);

create table isresponsiblefor
	(zkid integer not null,
	 tid integer not null, 
	 aid char(15) not null,
	 duedate date,
	 isdone char(1 byte)  null,
	 primary key (zkid, tid, aid),
	 foreign key (zkid) references zookeeper ON DELETE CASCADE,
	 foreign key (tid) references task ON DELETE CASCADE,
	 foreign key (aid) references animalslivein ON DELETE CASCADE);


create table attractioninfo 
	(attractionid integer not null,
	 attractionname varchar(200) null,
	 minpoints integer null,
	 sectionname char(50) null,
	 primary key (attractionid),
	 foreign key (sectionname) references zoosection ON DELETE CASCADE);

create table attractionisin
	(attractionid integer not null,
	 showtime timestamp not null,
	 showdate date not null, 
	 primary key (attractionid, showtime, showdate),
	 foreign key (attractionid) references attractioninfo ON DELETE CASCADE);


create table coordinates
	(zkid integer not null, 
	 showtime timestamp not null,
	 showdate date not null, 
	 attractionid integer not null,
	 primary key (zkid, showtime, showdate, attractionid),
	 foreign key (zkid) references zookeeper ON DELETE CASCADE,
	 foreign key (attractionid, showtime, showdate) references attractionisin ON DELETE CASCADE);


create table performsin
	(aid char(15) not null,
	 attractionid integer not null, 
	 showtime timestamp not null,
	 showdate date not null,
	 primary key (aid, attractionid, showtime, showdate),
	 foreign key (aid) references animalslivein ON DELETE CASCADE,
	 foreign key (attractionid, showtime, showdate) references attractionisin ON DELETE CASCADE);

create table sees
	(email char(50) not null,
	 attractionid integer not null, 
	 showtime timestamp not null,
	 showdate date not null, 
	 primary key (email, attractionid, showtime, showdate),
	 foreign key (email) references zoogoers ON DELETE CASCADE,
	 foreign key (attractionid, showtime, showdate) references attractionisin ON DELETE CASCADE);





insert into zoogoers
 values('williestroker@outlook.com', 'Willie', 'Stroker');

insert into zoogoers
 values('bendover@aol.com', 'Ben', 'Dover');

insert into zoogoers
 values('mikehawk@yahoo.com', 'Mike', 'Hawk');

insert into zoogoers
 values('dixienormus@gmail.com', 'Dixie', 'Normus');

insert into zoogoers
 values('jackgoff@gmail.com', 'Jack', 'Goff');

insert into zoogoers
 values('freecandy@sympatico.ca', 'Candy', 'Cummings');

insert into zoogoers
 values('dragonslayer444@aol.com', 'Bud', 'Light');

insert into zoogoers
 values('arham@rogers.com', 'Anass', 'Rhammar');

insert into zoogoers
 values('judyswallows@gmail.com', 'Judy', 'Swallows');

insert into zoogoers
 values('oliverl@yahoo.com', 'Oliver', 'Loser');




insert into member
 values('freecandy@sympatico.ca', 10001, 5, 1);

insert into member
 values('dragonslayer444@aol.com', 10002, 10, 2);

insert into member
 values('arham@rogers.com', 10003, 50, 25);

insert into member
 values('judyswallows@gmail.com', 10004, 20, 50);

insert into member
 values('oliverl@yahoo.com', 10005, 30, 0);




insert into shiftmapping
 values('17-OCT-16 09:00:00', '17-OCT-16');

insert into shiftmapping
 values('17-OCT-16 12:00:00', '17-OCT-16');

insert into shiftmapping
 values('18-OCT-16 09:00:00', '18-OCT-16');

insert into shiftmapping
 values('19-OCT-16 09:00:00', '19-OCT-16');

insert into shiftmapping
 values('20-OCT-16 09:00:00', '20-OCT-16');




insert into shift
 values(1, '17-OCT-16 09:00:00', '17-OCT-16 17:00:00');

insert into shift
 values(2, '17-OCT-16 09:00:00', '17-OCT-16 13:00:00');

insert into shift
 values(3, '17-OCT-16 12:00:00', '17-OCT-16 17:00:00');

insert into shift
 values(4, '18-OCT-16 09:00:00', '18-OCT-16 17:00:00');

insert into shift
 values(5, '19-OCT-16 09:00:00', '19-OCT-16 17:00:00');

insert into shift
 values(6, '20-OCT-16 09:00:00', '20-OCT-16 17:00:00');





insert into zookeeper
 values(1, 'Bill', 'Jenkins');

insert into zookeeper
 values(2, 'Melissa', 'Hawkins');

insert into zookeeper
 values(3, 'Alana', 'Morris');

insert into zookeeper
 values(4, 'Darren', 'Powers');

insert into zookeeper
 values(5, 'Trevor', 'Kevins');


insert into zoosection
 values('Africa Land', 'Animals one would find in Africa');

insert into zoosection
 values('Sea World Land', 'Animals one would find in the ocean');

insert into zoosection
 values('Bird World', 'A tropical setting for birds');

insert into zoosection
 values('Arctic Area', 'A frigid section for the polar bears that we do not have');

insert into zoosection
 values('Desert Dunes', 'For the camels and cobras that we used to have');

 


insert into attractioninfo
 values(1, 'Ring of Fire', 50, 'Africa Land');

insert into attractioninfo
 values(2, 'Whale of a Time', 10, 'Sea World Land');

insert into attractioninfo
 values(3, 'Cats: the Musical (but with Lions)', 20, 'Africa Land');

insert into attractioninfo
 values(4, 'Elephant Extravagansa', 0, 'Africa Land');

insert into attractioninfo
 values(5, 'Tribute to Harambe', 5, 'Africa Land');



insert into attractionisin
 values(1,'17-OCT-16 12:30:00', '17-OCT-16');

insert into attractionisin
 values(1,'17-OCT-16 16:30:00', '17-OCT-16' );

insert into attractionisin
 values(2, '17-OCT-16 09:30:00', '17-OCT-16');

insert into attractionisin
 values(3, '17-OCT-16 14:30:00', '17-OCT-16');

insert into attractionisin
 values(4, '17-OCT-16 12:30:00', '17-OCT-16');

insert into attractionisin
 values(5, '17-OCT-16 14:00:00', '17-OCT-16');






insert into coordinates
 values(1, '17-OCT-16 12:30:00', '17-OCT-16', 1);

insert into coordinates
 values(1, '17-OCT-16 16:30:00', '17-OCT-16', 1);

insert into coordinates
 values(2, '17-OCT-16 09:30:00', '17-OCT-16', 2);

insert into coordinates
 values(3, '17-OCT-16 14:30:00', '17-OCT-16', 3);

insert into coordinates
 values(1, '17-OCT-16 12:30:00', '17-OCT-16', 4);

insert into coordinates
 values(2, '17-OCT-16 12:30:00', '17-OCT-16', 4);

insert into coordinates
 values(1, '17-OCT-16 14:00:00', '17-OCT-16', 5);




insert into workson
 values(1, 1);

insert into workson
 values(1, 4);

insert into workson
 values(1, 5);

insert into workson
 values(1, 6);

insert into workson
 values(2, 2);

insert into workson
 values(3, 3);

insert into workson
 values(4, 4);

insert into workson
 values(5, 5);

insert into workson
 values(5, 6);




insert into task
 values(1, 'Clean cage');

insert into task
 values(2, 'Feed');

insert into task
 values(3, 'Bathe');

insert into task
 values(4, 'Play');

insert into task
 values(5, 'Medicate');






insert into enclosureisin
 values(1, 'Africa Land', 1, 2000);

insert into enclosureisin
 values(2, 'Africa Land', 2, 3000);

insert into enclosureisin
 values(3, 'Sea World Land', 1, 1500);

insert into enclosureisin
 values(4, 'Africa Land', 2, 1000);

insert into enclosureisin
 values(5, 'Bird World', 1, 500);




insert into animalslivein
 values('Gorilla1', 'Male', 'Gorilla', 'Harambe Jr.', 'Replaces Harambe physically, but he cannot replace his memory. RIP', '05-MAY-16', 1);

insert into animalslivein
 values('Lion1', 'Male', 'Lion', 'Larry', 'Cub of Dolores and Max from African safari trip', '10-APR-10', 2);

insert into animalslivein
 values('Lion2', 'Female', 'Lion', 'Lisa', 'Cub of Dolores and Max from African safari trip', '24-DEC-12', 2);

insert into animalslivein
 values('Whale1', 'Female', 'Whale', 'Willy', 'Found on a beach', '05-JULY-05', 3);

insert into animalslivein
 values('Elephant1', 'Male', 'Elephant', 'Eleanor', 'Acquired through illegal trade', '11-JUL-14', 4);



insert into isresponsiblefor
 values(1, 5, 'Gorilla1', '17-OCT-16', 1);

insert into isresponsiblefor
 values(1, 2, 'Lion1', '17-OCT-16', 0);

insert into isresponsiblefor
 values(2, 2, 'Lion2', '17-OCT-16', 0);

insert into isresponsiblefor
 values(3, 1, 'Elephant1', '17-OCT-16', 1);

insert into isresponsiblefor
 values(4, 5, 'Whale1', '17-OCT-16', 0);

insert into isresponsiblefor
 values(5, 3, 'Lion2', '17-OCT-16', 0);




insert into performsin
 values('Lion1', 1, '17-OCT-16 12:30:00', '17-OCT-16');

insert into performsin
 values('Lion2', 1, '17-OCT-16 16:30:00', '17-OCT-16');

insert into performsin
 values('Whale1', 2, '17-OCT-16 09:30:00', '17-OCT-16');

insert into performsin
 values('Lion2', 3, '17-OCT-16 14:30:00', '17-OCT-16');

insert into performsin
 values('Lion1', 3, '17-OCT-16 14:30:00', '17-OCT-16');

insert into performsin
 values('Elephant1', 4, '17-OCT-16 12:30:00', '17-OCT-16');

insert into performsin
 values('Gorilla1', 5, '17-OCT-16 14:00:00', '17-OCT-16');




insert into sees
 values('arham@rogers.com', 2, '17-OCT-16 09:30:00', '17-OCT-16');

insert into sees
 values('arham@rogers.com', 3, '17-OCT-16 14:30:00', '17-OCT-16');

insert into sees
 values('arham@rogers.com', 4, '17-OCT-16 12:30:00', '17-OCT-16');

insert into sees
 values('judyswallows@gmail.com', 5, '17-OCT-16 14:00:00', '17-OCT-16');

insert into sees
 values('judyswallows@gmail.com', 4, '17-OCT-16 12:30:00', '17-OCT-16');



CREATE SEQUENCE mid_counter START WITH 10006 INCREMENT BY 1;

CREATE SEQUENCE eid_counter START WITH 6 INCREMENT BY 1;

CREATE SEQUENCE aid_help_counter START WITH 6 INCREMENT BY 1;

CREATE SEQUENCE shift_counter START WITH 7 INCREMENT BY 1;

CREATE SEQUENCE tid_counter START WITH 6 INCREMENT BY 1;

CREATE SEQUENCE zid_counter START WITH 6 INCREMENT BY 1;

CREATE SEQUENCE aid_counter START WITH 6 INCREMENT BY 1;





        